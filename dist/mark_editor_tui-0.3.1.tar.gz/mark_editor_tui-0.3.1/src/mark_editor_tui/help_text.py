"""Help texts shown by the Mark Editor TUI."""

from __future__ import annotations

from mark_editor_tui.constants import APP_NAME, RELEASE, VERSION


def shortcuts_markdown() -> str:
    """Return the keyboard-shortcuts cheat sheet as Markdown.

    Every command from the File, Edit, Format, Paragraph and Help menus is
    listed with all of its shortcuts. ``Ctrl+P`` is added separately because
    the command palette is not part of a menu.
    """
    return f"""# {APP_NAME} {VERSION} ({RELEASE}) — Keyboard Shortcuts

The application runs in a terminal. The F1–F12 row follows the classic
console-editor layout and is the primary shortcut set. Ctrl and Alt combinations
remain available as aliases. The row ends with a clickable Ctrl+P command
palette hint. Scroll this page with PageUp/PageDown or the mouse wheel.


### File

| Action | Shortcut |
| :--- | :--- |
| New File | Ctrl+N |
| Open... | Ctrl+O |
| Reopen | Ctrl+Shift+O |
| Save | Ctrl+S, F2 |
| Save As... | Ctrl+Shift+S, F3 |
| Export... | Ctrl+E |
| Toggle Theme | Alt+T |
| Quit | F10 |


### Edit

| Action | Shortcut |
| :--- | :--- |
| Undo | Ctrl+Z, F11 |
| Redo | Ctrl+Y, F12 |
| Cut | Ctrl+X, Shift+Delete, F7 |
| Copy | Ctrl+C, F8 |
| Paste | Ctrl+V, Shift+Insert, F9 |
| Find... | Ctrl+F, F4 |
| Replace... | Ctrl+R, F5 |
| Select All | Ctrl+A, F6 |
| Remove Selection | Ctrl+Shift+A |
| Line Up | Alt+Up |
| Line Down | Alt+Down |
| Go to Line... | Ctrl+_ |
| Delete Line | Alt+D |


### Format

| Action | Shortcut |
| :--- | :--- |
| Bold | Ctrl+B |
| Italic | Alt+I |
| Underline | Ctrl+U |
| Strikethrough | Ctrl+D |
| Superscript | Ctrl+Shift+P |
| Subscript | Ctrl+Shift+B |
| Inline Code | Ctrl+K |
| Mark | Ctrl+Shift+M |
| Hyperlink... | Ctrl+L |
| Header ID... | Alt+H |
| Header Link... | Ctrl+Shift+H |
| TOC... | Ctrl+Shift+E |
| Footnote... | Ctrl+Shift+U |
| Date and Time... | Ctrl+Shift+D |
| Language Marker... | Ctrl+W, Alt+W |
| Language Wrapping... | Alt+Shift+W |
| Language Codes... | Alt+L |
| Furigana... | Ctrl+Shift+J |
| Emoji... | Alt+E |
| Special Signs... | Alt+S |
| Special Mark | Ctrl+Shift+L |
| Clear Formatting | Alt+Shift+F |


### Paragraph

| Action | Shortcut |
| :--- | :--- |
| Heading 1 | Alt+1 |
| Heading 2 | Alt+2 |
| Heading 3 | Alt+3 |
| Heading 4 | Alt+4 |
| Heading 5 | Alt+5 |
| Heading 6 | Alt+6 |
| Paragraph | Alt+0 |
| Ordered List... | Ctrl+G |
| Unordered List | Ctrl+Shift+G |
| Todo List... | Alt+C |
| Definition List... | Ctrl+Shift+X |
| Code Block... | Alt+Shift+K |
| Blockquote | Alt+Q |
| Table... | Ctrl+T |
| Add Table Row... | Ctrl+Shift+R |
| Table Alignment... | Alt+Shift+T |
| Balance Table | Alt+Shift+N |
| Image... | Alt+G |
| Horizontal Rule | Alt+- |
| Comment... | Alt+M |
| YAML Front Matter... | Ctrl+Shift+Y |
| Line Break | Alt+Enter |
| Add Indent | Tab |
| Remove Indent | Shift+Tab |


### Help

| Action | Shortcut |
| :--- | :--- |
| Keyboard Shortcuts | F1 |
| About Editor | — |


### Command palette

| Action | Shortcut |
| :--- | :--- |
| Command palette | Ctrl+P |
| Menus | Mouse click |
| Close menu or command palette | Esc |

The terminal emulator controls the font family and rendering size in the editor.
Exported HTML5 and PDF documents use the font stack embedded by
markdown2html5-base and are rendered by Chromium when printing PDFs.
"""


def about_markdown() -> str:
    """Return the About text as Markdown."""
    return f"""# {APP_NAME}

Version **{VERSION}** ({RELEASE})

A terminal Markdown editor written in Python with
[Textual](https://textual.textualize.io/).

It supports standard Markdown, GFM extensions, smart typography, table footers,
hidden comments, language markers, ruby annotations, emoji shortcodes, YAML Front
Matter and a table-of-contents generator.

Exports are available as styled HTML5 (portrait), PDF (portrait or landscape)
and plain text. PDF export writes a temporary HTML file, prints it with headless
Chromium using --no-pdf-header-footer and removes the file afterwards. Previewing
in a browser is intentionally not part of the TUI.
"""
